	project "BulletInverseDynamicsUtils"

	kind "StaticLib"

	includedirs {
		"../../src"
	}

	files {
		"*.cpp",
		"*.hpp"
	}
