#ifndef IMPORT_SDF_SETUP_H
#define IMPORT_SDF_SETUP_H


class CommonExampleInterface*    ImportSDFCreateFunc(struct CommonExampleOptions& options);


#endif //IMPORT_SDF_SETUP_H
