#ifndef TIME_SERIES_EXAMPLE_H
#define TIME_SERIES_EXAMPLE_H

class CommonExampleInterface*    TimeSeriesCreateFunc(struct CommonExampleOptions& options);



#endif//TIME_SERIES_EXAMPLE_H
