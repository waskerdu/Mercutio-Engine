# ShaderSet
GLSL shader live-reloading

Explanation here: https://nlguillemot.wordpress.com/2016/07/28/glsl-shader-live-reloading/
